# SortaCraft
Minecraft-like voxel game built with Three.js  
Play now @ https://tussiez.github.io/sortacraft/  
